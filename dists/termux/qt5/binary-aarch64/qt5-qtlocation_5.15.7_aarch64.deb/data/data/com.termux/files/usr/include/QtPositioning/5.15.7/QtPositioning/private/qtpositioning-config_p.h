#define QT_FEATURE_gypsy -1
#define QT_FEATURE_winrt_geolocation -1
