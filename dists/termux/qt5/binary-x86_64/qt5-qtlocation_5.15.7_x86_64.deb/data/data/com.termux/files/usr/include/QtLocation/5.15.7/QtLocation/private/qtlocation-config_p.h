#define QT_FEATURE_geoservices_esri 1
#define QT_FEATURE_geoservices_here 1
#define QT_FEATURE_geoservices_itemsoverlay 1
#define QT_FEATURE_geoservices_mapbox 1
#define QT_FEATURE_geoservices_mapboxgl -1
#define QT_FEATURE_geoservices_osm 1
#define QT_FEATURE_location_labs_plugin -1
