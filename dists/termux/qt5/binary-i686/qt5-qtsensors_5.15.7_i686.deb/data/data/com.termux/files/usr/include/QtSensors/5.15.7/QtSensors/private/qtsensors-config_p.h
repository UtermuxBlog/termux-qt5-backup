#define QT_FEATURE_sensorfw -1
